efinehm2.zip            Embedded CPU Ethernet code for EtherHM2 ROM
7i96s-hm2.zip           Hostmot2 VHDL source for Efinix FPGAs
7i96s25-hm2.zip         Alternate source for slower denser configs

