//demomove.c
//Simple motion control program
//for 4i34/4i34M "Anything I/O" boards.
//v.1.00  Dec 20, 2001.

#include <dos.h>
#include <stdio.h>
#include <stdlib.h>
#include <8259.h>
#include <hostmlow.h>
#define CHANNELS 4

extern unsigned _stklen  =  8192U;
extern unsigned _heaplen = 32768U;

struct TraceRec      {
  long TRDesPos;
  long TRPosErr;
  int  TRDrive ;
					 };

struct Motorx 	     {
	  long CurPos;
	  long DesPos;
	  long NewPos;
	  long FinalPos;
	  unsigned DesFrac;
	  long LastPos;
	  long PosErr;
	  int MaxPosErr;
	  int MinPosErr;
	  int PosErrForStop;
	  long IntegralErr;
	  long Accel;
	  long MaxVel;
	  long SignedMaxVel;
	  long Velocity;
	  long DesVel;
	  int ActVel;
	  long HalfPos;
	  int  KP;
	  int  KD;
	  long KI;
	  long IL;
	  int  KF;
	  long DeadZone;
	  int RunProfile;
	  int PIDOn;
	  int EXPE;
					   };

struct Motorx * MotorP;


const unsigned char TheInterrupt    = 10;
const unsigned      BasePort        = 0x220;
const int           LastMotor       = 3;
const int           LastActiveMotor = 3;
const int           TraceMax        = 100;


struct TraceRec StartTraceBuffer[500];
struct TraceRec EndTraceBuffer[500];
unsigned StartTraceCount;
unsigned EndTraceCount;
unsigned TraceCount;
void interrupt ( *OldVector) ();

struct Motorx Motors[CHANNELS];

unsigned char IRQDiv;
char FooKey;
unsigned char CurChan;
// interrupt variables
unsigned char dummy;
unsigned countlow, counthigh;
long longdrive;
long tdespos, tdesvel;
unsigned signfix, axt, bxt, cxt, tdesfrac;
unsigned SSSave;
unsigned SPSave;
unsigned NewSS;
unsigned NewSP;
unsigned LWtdespos;
unsigned HWtdespos;
unsigned LWtdesvel;
unsigned HWtdesvel;

void startup(void)
{
  for (CurChan = 0; CurChan <= LastMotor; CurChan++)
	{
	  Motors[CurChan].DesPos = 0;
	  Motors[CurChan].CurPos = 0;
	  Motors[CurChan].Velocity = 0;
	  Motors[CurChan].Accel = 0;
	  Motors[CurChan].MaxVel = 0;
	  Motors[CurChan].PosErrForStop = 500;
	  Motors[CurChan].IntegralErr = 0;
	  Motors[CurChan].KD = 3500;
	  Motors[CurChan].KP = 500;
	  Motors[CurChan].KI = 80000;
	  Motors[CurChan].IL = 8192*65536; //1/8 FS
	  Motors[CurChan].KF = 900;
	  Motors[CurChan].KI = 0;
	  Motors[CurChan].IL = 0;
	  Motors[CurChan].KF = 0;
	  Motors[CurChan].RunProfile = 0;
	  Motors[CurChan].DeadZone = 1;
	  Motors[CurChan].PIDOn = 0;
	  Motors[CurChan].EXPE = 0;
	  StartTraceCount = 1;
	  EndTraceCount = 1;
	  // do per channel setup stuff
	  outportb((BasePort+IndexReg), CurChan);
	  outport((BasePort + CCReg), 0x54);  // local Count enable + latch on read + clear counters
	  outportb((BasePort + PCReg), 0x01); // local PWM enable
	}

  outportb((BasePort + GMReg), 0x03); // global PWM enable and Count enable
  outportb((BasePort +LEDReg), 0x01); // set LED reg to point to channel 1
  IRQDiv = 4;
  NewSS = _SS;
  NewSP = _SP - 4096;     // we will use the current stack later...

}

void usage(void)
{
  printf("USAGE: movec ");
  exit (1);
}

long     * lPtr;
unsigned * uPtr;

int LiiR_HW(long Value)
  {
	lPtr = &Value;
	uPtr = (unsigned*)lPtr;
	return ((int)(*(++uPtr)));
  }

unsigned LiR_LW(long Value)
  {
	lPtr = &Value;
	uPtr = (unsigned*)lPtr;
	return (*(uPtr));
  }

unsigned LiR_HW(long Value)
  {
	lPtr = &Value;
	uPtr = (unsigned*)lPtr;
	return (*(++uPtr));
  }


void PID(void)
{
  // Do all motors
  for (CurChan = LastActiveMotor; (signed char) CurChan >= 0; CurChan--)
	{
	  // General things done every tic
	  outportb((BasePort+IndexReg), CurChan);       // select channel
	  countlow  = inport(BasePort + CountLowReg );  // read current position
	  counthigh = inport(BasePort + CountHighReg);
	  Motors[CurChan].CurPos = countlow + (counthigh*65536);
	  Motors[CurChan].PosErr = Motors[CurChan].CurPos - Motors[CurChan].DesPos;
	  if (Motors[CurChan].PosErr > Motors[CurChan].MaxPosErr)
	{
	  Motors[CurChan].MaxPosErr = Motors[CurChan].PosErr;
	}
	  if (Motors[CurChan].PosErr < Motors[CurChan].MinPosErr)
	{
	  Motors[CurChan].MinPosErr = Motors[CurChan].PosErr;
	}
	  Motors[CurChan].ActVel  = Motors[CurChan].LastPos-Motors[CurChan].CurPos;
	  Motors[CurChan].LastPos = Motors[CurChan].CurPos;

	  // PID loop motor drive math
	  if (Motors[CurChan].PIDOn)
	{
	  Motors[CurChan].IntegralErr = Motors[CurChan].IntegralErr
					  + Motors[CurChan].PosErr
					  * Motors[CurChan].KI;

	  if (Motors[CurChan].IntegralErr > Motors[CurChan].IL)
	{
	  Motors[CurChan].IntegralErr =  Motors[CurChan].IL;   // bound IntegralErr by IL
	}
	  if (Motors[CurChan].IntegralErr < -Motors[CurChan].IL)
	{
	  Motors[CurChan].IntegralErr = -Motors[CurChan].IL;
	}
	// this is the actual PID loop calculation:
	longdrive  = Motors[CurChan].KP * Motors[CurChan].PosErr  // Proportional term
		   + LiiR_HW(Motors[CurChan].IntegralErr)         // Integral term
		   - Motors[CurChan].KD * (Motors[CurChan].ActVel
		   + LiiR_HW(Motors[CurChan].DesVel))             // Derivative term
		   - Motors[CurChan].KF
		   * LiiR_HW(Motors[CurChan].DesVel);             // Velocity feed forward term
	if (longdrive >  32700) {longdrive =  32700;}
	if (longdrive < -32700) {longdrive = -32700;}
	if ((Motors[CurChan].Velocity == 0) && (labs(longdrive) < Motors[CurChan].DeadZone)) {longdrive = 0;}
	outport((BasePort+PWMReg), (int)longdrive);
	if (abs(Motors[CurChan].PosErr) > Motors[CurChan].PosErrForStop)
	{
	  outport((BasePort+PWMReg), 0);  // if we're out of range, set the motor drive to 0
	  Motors[CurChan].PIDOn = 0;      // turn the PID loop off
	  Motors[CurChan].EXPE  = 1;      // set the excessive position error flag
	  Motors[CurChan].RunProfile = 0; // stop running profile - were not going anywhere
	}
  }
	  // profile generator
	  if ((Motors[CurChan].RunProfile) == 1)
	  {
	if (CurChan == 1)
	{
	  if (StartTraceCount < TraceMax)
	  {
		StartTraceBuffer[StartTraceCount].TRDesPos = Motors[CurChan].DesPos;
		StartTraceBuffer[StartTraceCount].TRPosErr = Motors[CurChan].PosErr;
		StartTraceBuffer[StartTraceCount].TRDrive  = (int)longdrive;
		StartTraceCount = StartTraceCount + 1;
	  }
	  EndTraceBuffer[EndTraceCount].TRDesPos = Motors[CurChan].DesPos;
	  EndTraceBuffer[EndTraceCount].TRPosErr = Motors[CurChan].PosErr;
	  EndTraceBuffer[EndTraceCount].TRDrive  = (int)longdrive;
	  EndTraceCount = EndTraceCount + 1;
	  if (EndTraceCount > TraceMax) {EndTraceCount = 1;}
	}

	if (Motors[CurChan].DesPos < Motors[CurChan].HalfPos)
	{
	  Motors[CurChan].Velocity = Motors[CurChan].Velocity + Motors[CurChan].Accel;
	}
	else
	{
	  Motors[CurChan].Velocity = Motors[CurChan].Velocity - Motors[CurChan].Accel;
	}
	if (Motors[CurChan].Velocity == 0)    // we're done!
	{
	  Motors[CurChan].FinalPos = Motors[CurChan].DesPos;
	  Motors[CurChan].RunProfile = 0;
	  Motors[CurChan].Accel = 0;
	  Motors[CurChan].DesPos = Motors[CurChan].NewPos;
	  Motors[CurChan].Velocity = 0;
	  Motors[CurChan].DesVel = 0;
	}
	if (abs(Motors[CurChan].Velocity) <= Motors[CurChan].MaxVel)
	{
	  Motors[CurChan].DesVel = Motors[CurChan].Velocity;
	}
	else
	{
	  Motors[CurChan].DesVel = Motors[CurChan].SignedMaxVel;
	}
	if (Motors[CurChan].DesVel < 0)
	{
	  signfix = 0xFFFF;
	}
	else
	{
	  signfix = 0x0000;
	}
	tdespos  = Motors[CurChan].DesPos;
	tdesfrac = Motors[CurChan].DesFrac;
	tdesvel  = Motors[CurChan].DesVel;
	LWtdespos = LiR_LW(tdespos);
	HWtdespos = LiR_HW(tdespos);
	LWtdesvel = LiR_LW(tdesvel);
	HWtdesvel = LiR_HW(tdesvel);
	asm 	{
	  mov ax,tdesfrac;   // get three words
	  mov bx,LWtdespos;
	  mov cx,HWtdespos;
	  // do the add
	  add ax,LWtdesvel;
	  adc bx,HWtdesvel;
	  // last add fixes sign
	  adc cx,signfix;
	  // restore data (why the casts above dont work here I do not know...)
	  mov axt,ax
	  mov bxt,bx
	  mov cxt,cx
	}
	// restore values in motor record
	// doesnt work in asm for some reason
	Motors[CurChan].DesFrac = axt;
	Motors[CurChan].DesPos  = ((((long)cxt) << 16) | ((long)bxt));

   }
   dummy = inportb((int)(BasePort + (unsigned)IRQSelReg)); // clear interrupt
  }
  IssueEOI2();
}

void interrupt NEWISR()
// this is the actual hardware interrupt routine
// all it does is create a local stack for us to so we
// do not have to depend on the kindness of strangers...
{
  asm     {
	mov AX,SS          // save old SS and SP
	mov SSSave,AX
	mov AX,SP
	mov SPSave,AX
	mov AX,NewSS
	mov SS,AX
	mov AX,NewSP
	mov SP,AX
  }
  PID();
  asm     {
	mov AX,SSSave      // restore old SS and SP (we hope)
	mov SS,AX
	mov AX,SPSave
	mov SP,AX
  }
} // InterruptServiceRoutine

void Move(unsigned char chan, long nextpos, long acc, long maxv)
{
  printf("Chan %d", chan);
  printf("  Move to %d\n", nextpos);

	DisableInterrupts();
	Motors[chan].MaxVel = maxv;
	if ((nextpos - Motors[chan].DesPos) < 0)
	{
	  Motors[chan].SignedMaxVel = -maxv;
	}
	else
	{
	  Motors[chan].SignedMaxVel = maxv;
	}
	Motors[chan].HalfPos = (Motors[chan].DesPos + nextpos) / 2;
	Motors[chan].NewPos  = nextpos;
	Motors[chan].LastPos = Motors[chan].CurPos;
	Motors[chan].Accel = acc;
	Motors[chan].Velocity = 0;
	Motors[chan].DesVel = 0;
	Motors[chan].DesFrac = 32768;
	Motors[chan].MaxPosErr = 0;
	Motors[chan].MinPosErr = 0;
	Motors[chan].RunProfile = 1;
	Motors[chan].EXPE = 0;
	Motors[chan].PIDOn = 1;
	StartTraceCount = 1;
	EndTraceCount = 1;
	EnableInterrupts();
}

int ProfileRunning(unsigned char theMotor)
{
  return Motors[theMotor].RunProfile;
}

int MotorEXPE(unsigned char theMotor)
{
  return Motors[theMotor].EXPE;
}

void PIDOn(unsigned char theMotor)
{
  Motors[theMotor].PIDOn = 1;
}

void StartInterrupts(void)
{
  DisableInterrupts();
  OldVector = getvect(InterruptNumber(TheInterrupt));
  setvect(InterruptNumber(TheInterrupt), NEWISR);
  outportb((BasePort + IRQSelReg), (TheInterrupt + 0x10)); // select IRQ + enable driver
  outportb((BasePort + IRQDivReg), IRQDiv);
  outportb((BasePort + IRQSelReg), (TheInterrupt + 0x30)); // select IRQ + enable driver + unmask
  UnMaskInterrupt(TheInterrupt);
  EnableInterrupts();
  printf("Control loop running...\n");
}

void StopInterrupts(void)
{
  DisableInterrupts();
  outportb((BasePort + GMReg), 0x00); // Disable all PWM outputs
  setvect(InterruptNumber(TheInterrupt), OldVector);
  outportb((BasePort + IRQSelReg), 0); // Disable driver
  outportb((BasePort + IRQDivReg), 0);
  UnMaskInterrupt(TheInterrupt);
  EnableInterrupts();
  for (CurChan = 0; CurChan <= LastMotor; CurChan++)
  {
	  outportb((BasePort + IndexReg), CurChan);
	  outportb((BasePort + PCReg), 0x00); // turn off enable bit on interface
  }
  printf("Control loop shut down\n");
}

void WaitForMotors()
{
  while (ProfileRunning(0) || ProfileRunning(1))
  {
	  printf(" PE= %d",     Motors[1].PosErr);
	  printf(" AV= %d",     Motors[1].ActVel);
	  printf(" MSDV= %d",   LiiR_HW(Motors[1].DesVel));
	  printf(" MSIE= %d\n", LiiR_HW(Motors[1].IntegralErr));

	if (MotorEXPE(0) || MotorEXPE(1))
	{
	  printf("Shut down due to excessive position error\n");
	  StopInterrupts();
	  exit(2);
	}
  }
  printf("Got to (0,1) %d,   %d\n", Motors[0].DesPos, Motors[1].DesPos);
  printf("DDA Got to (0,1) %d,   %d\n", Motors[0].FinalPos, Motors[1].FinalPos);
  printf("MaxPosErr = %d,  MinPosErr = %d\n", Motors[0].MaxPosErr, Motors[0].MinPosErr);
  printf("Trace of first TraceMax tics\n");
  for (StartTraceCount = 1; StartTraceCount <= TraceMax; StartTraceCount++)
  {
	printf
	(" %d,  %d,  %d,\n",
	StartTraceBuffer[StartTraceCount].TRDesPos,
	StartTraceBuffer[StartTraceCount].TRPosErr,
	StartTraceBuffer[StartTraceCount].TRDrive);
	if ((StartTraceCount % 5) == 0) { printf("\n"); }
  }
  printf("Press any key to continue...");
  while(!kbhit()); // do nothing
  printf("Trace of Last TraceMax tics");
  // we start this loop in the location in the EndTraceBuffer
  // at 1 past the last location written to (the oldest location)
  for (TraceCount = 1; TraceCount <= TraceMax; TraceCount++)
  {
	printf
	(" %d,  %d,  %d,\n",
	EndTraceBuffer[EndTraceCount].TRDesPos,
	EndTraceBuffer[EndTraceCount].TRPosErr,
	EndTraceBuffer[EndTraceCount].TRDrive);
	if ((TraceCount % 5) == 0)
	{ printf("\n"); }
	EndTraceCount++;
	if (EndTraceCount > TraceMax) { EndTraceCount = 1; }
  }
  printf("Press any key to continue...");
  while(!kbhit()) // do nothing;
  printf("Continue");

}

int main (int argc)
{
  if (argc > 1)
	{
	  usage();
	}
  startup();
  StartInterrupts();
  PIDOn(0);
  PIDOn(1);
  delay(10);
  do
  {
	delay(50);
	Move(0,0,44,250000);
	Move(1,0,44,250000);
	WaitForMotors();
	Move(0, 2640*3,98,250000);
	Move(1,-2640*3,98,250000);
	WaitForMotors();
	Move(0,-2640*3,98,250000);
	Move(1, 2640*3,98,250000);
	WaitForMotors();
  } while (kbhit() == 0);
  StopInterrupts();
  return 0;
}
