IOPR24-1.BIT    IOPR24 bitfile for 1M 3X20, 7I68 pinout
IOPR24-2.BIT    IOPR24 bitfile for 2M 3X20, 7I68 pinout

These need to be recompiled with 3x20.ucf for native 3x20 pinout


